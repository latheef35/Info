import com.usbank.*

def call(Closure body) {
  def config = [:]
  body.resolveStrategy = Closure.DELEGATE_FIRST
  body.delegate = config
  body()
  run(config)    
}

def run(config) {
  def emailId = config.emailId
  def subject = config.get("subject", "*****No Subject Set******")
  def body = config.get("body", "*****No Email Body*****")
  timestamps {
    ansiColor('xterm') {
      if(!emailId) {
        error "emailId is the required parameter."
      }
    
      mail(to: emailId, subject: subject, body: body)
    }
  }
}

return this;
