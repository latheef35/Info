import com.usbank.*
import groovy.json.JsonOutput

def call(Closure body) {
  def config = [:]
  body.resolveStrategy = Closure.DELEGATE_FIRST
  body.delegate = config
  body()
  tag(config)
}

def tag(config) {
  def project = new ProjectProperties()
  project.loadProjectProperties()
  def timeOutDuration = config.get('timeOutDuration', 5)
  def tagInformation = null
  def date = new Date()
  def finalDate = date.format('yyyy-MM-dd HH:mm:ss')
  def environment = config.get('environment', 'dev')
  def applicationType = config.get('applicationType', 'proxy')
  def tagName = config.get('tagName', "1.0.${env.BUILD_NUMBER}")
  def branchName = config.get('branchName', "master")
  
  if(environment.toLowerCase() == "it") {
    tagName = tagName + "-it"  
  }

  config['gitTagName'] = tagName
  config['gitCommitHash'] = project['commitHash']
  config['gitLabProjectName'] = project['projectName']
  config['gitLabProjectUrl'] = project['projectUrl']
  config['gitReleaseDescription'] = "Tagging the branch with production release tag and date create: ${finalDate}"
  config['branchName'] = branchName
  
  gitlab.tagProject(config)
  collectEvidence(config)
}

def collectEvidence(config) {
  def urlSplit = config.gitLabProjectUrl.split('/')
  try {
    def date = new Date()
    def finalDate = date.format('yyyy-MM-dd HH:mm:ss')
    def evidence = [
      data: [ 
        [
          scmUrl: config.gitLabProjectUrl,
          commitHash: config.gitCommitHash,
          branch: config.branchName,
          jenkinsUrl: env.BUILD_URL,
          buildNumber: env.BUILD_NUMBER,
          jobSubmitter: utils.getBuildUserId(),
          tagName: config.gitTagName
        ]
      ],
      recordCreateDate: finalDate
    ]

    def data = [
      applicationName: config.gitLabProjectName,
      applicationType: config.applicationType,
      evidenceType: "TagRepository",
      carId: env.CARID,
      environment: config.environment,
      lineOfBusiness: urlSplit[4].toLowerCase(),
      majorVersion: config.gitTagName,
      owner: env.OWNER,
      evidence: evidence
    ]
    
    echo data.toString()
    config['data'] = utils.generateEvidenceData(data)
    evidenceStorage.add(config)
  } catch(Exception ex) {
    echo "WARN: unable to add evidence to evidence storage"
  }
}

return this;