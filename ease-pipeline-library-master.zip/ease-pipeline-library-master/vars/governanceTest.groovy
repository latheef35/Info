import com.usbank.*

def call(Closure body) {
  def config = [:]
  body.resolveStrategy = Closure.DELEGATE_FIRST
  body.delegate = config
  body()
  execute(config)    
}

def execute(config) {
  def pipelineProperties = new PipelineProperties()
  def pathToGovernanceTestSuite = config.get('pathToGovernanceTestSuite', pipelineProperties.get('governance.test.suite.jenkins.path'))
  def proxyName = config.get('proxyName', '')
  def apigeeOrganizationName = config.get('apigeeOrganizationName', 'usbank-test')
  def timeOutDuration = config.get('timeOutDuration', 24)
  def approversList = pipelineProperties.get('governance.test.approver.list')
  def emailId = config.get('emailId', '')
  def gitProjectName = config.get('gitProjectName', '')
  def buildUrl = env.BUILD_URL
  def gitUrl = config.get('gitUrl',pipelineProperties.get('governance.test.git.url'))
  def gitToken = config.get('gitToken', pipelineProperties.get('gitlab.api.token'))
  def gitBranch = config.get('gitBranch','master')
  def kibanaApiId = config.get('kibanaApi', pipelineProperties.get('kibana.api.credential.id'))
  def apigeeCredentialId = config.get('apigeeCredentialId', pipelineProperties.get('onprem-credential.id'))
  def apigeeEnvironment = config.get('apigeeEnvironment', 'usb-onprem-dev')
  def testSuiteName = config.get('testSuiteName', 'governance-test-suite')
  def karateEnvironment = config.get('karateEnvironment','usb-dev')

  def err = null
  def status = 'PASSED'

  timestamps {
    ansiColor('xterm') {
      if(!proxyName) {
        error "proxyName not specified"
      }

      if(!apigeeOrganizationName) {
        error "apigeeOrganizationName not specified"
      }

      if(!emailId) {
        error "emailId not specified"
      }

      if(!gitProjectName) {
        error "gitProjectName not specified"
      }

      if(emailId != '') {
        emailId = emailId + ',' + pipelineProperties.get('governance.notifier.email.id')
      } else {
        emailId = pipelineProperties.get('governance.notifier.email.id')
      }
      
      // disabling this check since the governance test suite is running under the controlled environment
      // will be needing to enable this in future
      // input(id: 'userInput', message: 'Do you want to continue with the Governance test?')

      try {
        sh "git clone ${gitUrl}"
        token = utils.generateApigeeToken([env: apigeeEnvironment, credentialsId: apigeeCredentialId, proxyEnabled: false])
        withCredentials([usernamePassword(credentialsId: kibanaApiId, usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD')]) {
          withCredentials([string(credentialsId: gitToken, variable: 'TOKEN')]) {
            def args = ["-Dkibana.user=$USERNAME", "-Dkibana.password=$PASSWORD", "-Dgit.project.name=${gitProjectName}", "-Dgit.token=$TOKEN", "-Dgit.branch=${gitBranch}", "-Dkarate.env=${karateEnvironment}", "-Dproxy.organization=${apigeeOrganizationName}", "-Dproxy.token=${token}", "-Dproxy.app.name=${proxyName}"]
            dir(testSuiteName) {
              mvnBuild.run([cucumberTestReportsEnabled: true, mavenGoals:'clean test', mavenArgs: args, collectEvidence: false])
            }
          }
        }
      } catch(Exception e) {
        status = 'FAILED'
        err = e
      } finally {
        def emailSubject =  "Job ${JOB_NAME} ${BUILD_NUMBER} ${status} for ${proxyName} in apigee ${apigeeOrganizationName}"
        def emailBody = "Please go to ${BUILD_URL}." + 
        "\n To look at the detailed results for proxy ${proxyName} in apigee for organization ${apigeeOrganizationName}." + 
        "\n Here is the link to the reports ${BUILD_URL}cucumber-html-reports/overview-features.html"
        notify.run([emailId: emailId, subject: emailSubject, body: emailBody]) 
        config['status'] = status
        if(status == 'FAILED') {
          echo "governance test has failed for the following api."
        }
      }

      timeout(time: timeOutDuration, units: 'HOURS') {
        input(message: "Final APPROVAL from the Governance team", ok: "OK", submitter: approversList)
      }
      collectEvidence(config)
    }
  }
}

def collectEvidence(config) {
  try {
    def date = new Date()
    def projName = config.gitProjectName.split("-")
    def testResultDir = config.get('testResultDir','target/surefire-reports')
    def evidence = [
      data: [ 
        [
          jenkinsUrl: env.BUILD_URL,
          buildNumber: env.BUILD_NUMBER,
          jobSubmitter: utils.getBuildUserId(),
          governanceTestStatus: config.status,
          governanceTestUrl: "${BUILD_URL}cucumber-html-reports/overview-features.html",
          apigeeOrganizationName: config.apigeeOrganizationName,
          karateEnvironment: config.karateEnvironment,
          contactEmailId: config.emailId,
          testApprover: config.approver
        ]
      ],
      recordCreateDate: date.format('yyyy-MM-dd HH:mm:ss')
    ]

    try {
      unstash 'reports'
      def testResults = []
      dir(testResultDir) {
        def listTestfile = sh(script:"ls *.json", returnStdout: true)
        def jsonFileNames = listTestfile.split("\\r?\\n");
        for(int i = 0; i < jsonFileNames.length; i++) {
          def testResult = readJSON file: jsonFileNames[i]
          testResults.addAll(testResult)
        }
        evidence['data'][0]["governanceTest"] = testResults
      }
      stash 'reports'
    } catch(Exception ex) {
      echo "No governance test results generated"
    }

    def data = [
      applicationName: config.gitProjectName,
      applicationType: projName[1],
      evidenceType: "GovernanceTest",
      carId: env.CARID,
      environment: 'it',
      lineOfBusiness: projName[2],
      majorVersion: "1.0.${env.BUILD_NUMBER}",
      owner: env.OWNER,
      evidence: evidence
    ]

    config['data'] = utils.generateEvidenceData(data)
    evidenceStorage.add(config)
  } catch(Exception ex) {
    echo "WARN: unable to add evidence to evidence storage"
  }
}

return this;
