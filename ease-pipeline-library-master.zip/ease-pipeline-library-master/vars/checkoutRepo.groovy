import com.usbank.*

def call(Closure body) {
  def config = [:]
  body.resolveStrategy = Closure.DELEGATE_FIRST
  body.delegate = config
  body()
  checkoutSourceCodeRepo(config)  
}

def checkoutSourceCodeRepo(config) {
  timestamps {
    ansiColor('xterm') {
      // cleaning up the old code
      deleteDir()
      // added config incase
      checkout scm
    }
  }
}

return this;
