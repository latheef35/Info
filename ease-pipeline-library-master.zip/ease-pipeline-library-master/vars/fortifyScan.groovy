import com.usbank.*

def call(Closure body) {
  def config = [:]
  body.resolveStrategy = Closure.DELEGATE_FIRST
  body.delegate = config
  body()
  execute(config)    
}

def execute(config) {
  def pipelineProperties = new PipelineProperties()
  def fortifyVersion = config.get('fortifyVersion', '')
  def fortifyApplication = config.get('fortifyApplication', '')
  def fortifyBuildId = config.get('fortifyBuildId', '')
  def fortifyUrl = config.get('fortifyUrl', pipelineProperties.get('fortify.prod.url'))
  def fortifyTokenId = config.get('fortifyTokenId', pipelineProperties.get('fortify.prod.token.id'))
  def fortifyEnv = config.get('fortifyEnv', 'prod')
  def changeDir = config.changeDir ?: '.'
  def defaultPomFileLocation = config.get('defaultPomFileLocation','pom.xml')
  def fortifyGoals = config.get('fortifyGoals','com.fortify.sca.plugins.maven:sca-maven-plugin::translate')
  def fortifyArgs = config.get('fortifyArgs', [])
  def sourceAnalyzerArgs = config.get('sourceAnalyzerArgs', [])
  def cloudScanArgs = config.get('cloudScanArgs', [])
  def languageType = config.get('languageType', 'java')
  def sourcePath = config.get('sourcePath', '')

  if(fortifyEnv != 'prod') {
    fortifyUrl = (fortifyEnv == 'dev' ? pipelineProperties.get('fortify.dev.url') : pipelineProperties.get('fortify.it.url'))
    fortifyTokenId = (fortifyEnv == 'dev' ? pipelineProperties.get('fortify.dev.token.id') : pipelineProperties.get('fortify.it.token.id'))
  }

  timestamps {
    ansiColor('xterm') {
      dir(changeDir) {
        if(languageType.toLowerCase() == "java") {
          javaScan(config)
        } 
  
        if (languageType.toLowerCase() == "javascript") {
          javaScriptScan(config)
        }
        
        if (languageType.toLowerCase() == "php") {
          phpScan(config)
        }
        
        withCredentials([string(credentialsId: fortifyTokenId, variable: 'TOKEN')]) {
          cloudScanArgs.addAll(["-sscurl ${fortifyUrl}", "-ssctoken ${TOKEN}", "start", "-upload",
                          "-application ${fortifyApplication}", "-version ${fortifyVersion}",
                          "-uptoken ${TOKEN}", "-b ${fortifyBuildId} -scan"])
          def cloudScanCmd = ["cloudscan", cloudScanArgs.unique().join(' ')]
          sh "${cloudScanCmd.join(' ')}"
        }
      }
      collectEvidence(config)
    }
  }
}

def javaScriptScan(config) {
  env.LANGUAGE_TYPE = "javascript"
  def sourceAnalyzerArgs = config.sourceAnalyzerArgs

  if(config.excludePath) {
    sourceAnalyzerArgs.addAll(["-exclude", config.excludePath])
  }

  if(!config.sourcePath) {
    // this will scan all the files and folders with all extension  
    config['sourcePath'] = '**/*'  
  }

  sourceAnalyzerArgs.addAll(["-b ${config.fortifyBuildId}", config.sourcePath])
  def sourceAnalyzerCmd = ["sourceanalyzer", sourceAnalyzerArgs.unique().join(' ')]
  echo "${sourceAnalyzerCmd.join(' ')}"
  sh "${sourceAnalyzerCmd.join(' ')}"
}

/*
 * function to execute the fortify scan for php based appilcation
 * sourceanalyzer -php-source-root <srpath> -b <build_id> MyPHP.php
 */
def phpScan(config) {
  env.LANGUAGE_TYPE = "php"
  def sourceAnalyzerArgs = config.sourceAnalyzerArgs
  
  sourceAnalyzerArgs.addAll(["-b ${config.fortifyBuildId}"])
  
  if(!config.rootPath) {
    sourceAnalyzerArgs.addAll(["-php-source-root", pwd()])  
  } else {
    sourceAnalyzerArgs.addAll(["-php-source-root", config.rootPath])  
  }
  
  if(!config.sourcePath) {
    // this will scan all the files and folders with .php extension  
    config['sourcePath'] = '**/*'  
  }
  
  sourceAnalyzerArgs.addAll([config.sourcePath])
  
  if(config.excludePath) {
    sourceAnalyzerArgs.addAll(["-exclude", config.excludePath])    
  }
  
  def sourceAnalyzerCmd = ["sourceanalyzer", sourceAnalyzerArgs.unique().join(' ')]
  echo "${sourceAnalyzerCmd.join(' ')}"
  sh "${sourceAnalyzerCmd.join(' ')}"
}

def javaScan(config) {
  env.LANGUAGE_TYPE = "java"
  def sourceAnalyzerArgs = config.sourceAnalyzerArgs
  sourceAnalyzerArgs.addAll(["-clean", "-b ${config.fortifyBuildId}"])
  
  if(config.excludePath) {
    sourceAnalyzerArgs.addAll(["-exclude", config.excludePath])    
  }
  
  def sourceAnalyzerCmd = ["sourceanalyzer", sourceAnalyzerArgs.unique().join(' ')]
  def fortifyArgs = config.fortifyArgs
  
  // making all the fortify commands overwritable
  fortifyArgs.addAll(['-V', '-B', '-U', 
                      "-f ${config.defaultPomFileLocation}",
                      "-Dfortify.sca.buildId=${config.fortifyBuildId}"])
  sh "${sourceAnalyzerCmd.join(' ')}"
  mvnBuild.run([mavenGoals: "clean ${config.fortifyGoals}", mavenArgs: config.fortifyArgs, collectEvidenceFlag: false])
}

def collectEvidence(config) {
  try {
    def project = new ProjectProperties()
    project.loadProjectProperties()
    def date = new Date()
    def environment = 'dev'
    def defaultApplicationType = 'service'
    def url = project['projectUrl']
    def urlSplit = url.split('/')
    def lob = env.LOB
    
    def evidence = [
      data: [ 
        [
          scmUrl: project['projectUrl'],
          commitHash: project['commitHash'],
          branch: project['branch'],
          jenkinsUrl: env.BUILD_URL,
          buildNumber: env.BUILD_NUMBER,
          jobSubmitter: utils.getBuildUserId(),
          fortifyUrl: config.fortifyUrl,
          fortifyBuildId: config.fortifyBuildId,
          fortifyVersion: config.fortifyVersion,
          fortifyApplication: config.fortifyApplication,
          languageType: env.LANGUAGE_TYPE
        ]
      ],
      recordCreateDate: date.format('yyyy-MM-dd HH:mm:ss')
    ]
    
    if (project['projectName'].toString().contains("proxy")) {
       defaultApplicationType = "proxy"
       lob = urlSplit[4].toLowerCase()
    }
    
    if (project['projectName'].toString().toLowerCase().contains("sharedflow")) {
       defaultApplicationType = "sharedflow" 
       lob = urlSplit[4].toLowerCase()
    }

    def data = [
      applicationName: project['projectName'],
      applicationType: defaultApplicationType,
      evidenceType: "FortifyScan",
      carId: env.CARID,
      environment: environment,
      lineOfBusiness: lob,
      majorVersion: "1.0.${env.BUILD_NUMBER}",
      owner: env.OWNER,
      evidence: evidence
    ]

    config['data'] = utils.generateEvidenceData(data)
    evidenceStorage.add(config)
  } catch(Exception ex) {
    echo "WARN: unable to add evidence to evidence storage"
  }
}

return this;