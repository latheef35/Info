import com.usbank.*

def call(Closure body) {
  def config = [:]
  body.resolveStrategy = Closure.DELEGATE_FIRST
  body.delegate = config
  body()
  run(config)    
}

def run(config) {
  def pipelineProperties = new PipelineProperties()
  def project = new ProjectProperties()

  def proxyEnv = [
    proxyHost: pipelineProperties.get('proxy.host'),
    proxyPort: pipelineProperties.get('proxy.port'),
  ]
  
  def mavenHome = config.get('mavenHome', pipelineProperties.get('maven.home'))
  def mavenArgs = config.get('mavenArgs', [])
  def mavenGoals = config.get('mavenGoals', 'clean deploy')
  def mavenOpts = config.get('mavenOpts', [])
  def proxyEnabled = config.get('proxyEnabled', false)
  def defaultProxy = config.get('defaultProxy', proxyEnv)
  def defaultMavenSettings = config.get('defaultMavenSettings', '-s ./settings.xml')
  def mavenSettingsInJenkins = config.get('mavenSettingsInJenkins', true)
  def settingsFileId = config.get('settingsFileId','34950559-48e4-4c53-8e54-aac6381ab762')
  def junitTestReportsEnabled = config.get('junitTestReportsEnabled', false)
  def cucumberTestReportsEnabled = config.get('cucumberTestReportsEnabled', false)
  def htmlReportsEnabled = config.get('htmlReportsEnabled', false)
  def buildWithReleaseVersion = config.get('buildWithReleaseVersion', false)
  def collectEvidenceFlag = config.get('collectEvidence', true)

  def buildError = null
  def failedStatus = false

  project.loadProjectProperties()

  if(proxyEnabled) {
    mavenOpts.addAll([
      "-DproxyHost=${defaultProxy.proxyHost}",
      "-DproxyPort=${defaultProxy.proxyPort}",
      "-DproxySet=${proxyEnabled}",
    ])
  }

  if(mavenSettingsInJenkins) {
    try {
      configFileProvider([configFile(fileId: settingsFileId, variable: 'MAVEN_SETTINGS')]) {
        //copying the settings file from jenkins
        sh "cat $MAVEN_SETTINGS > settings.xml"
        defaultMavenSettings = "-s settings.xml"
      }
    } catch(Exception ex) {
      // Dont Throw any exception here
      // We will use the user input setting file here then
    }
  }
  
  // Adding the default options to the maven command
  mavenArgs.addAll(['-V', '-B', '-U'])
  mavenOpts.addAll(['-Djava.awt.headless=true'])
  mavenEnv = ["MAVEN_OPTS=${mavenOpts.unique().join(' ')}"]

  // Running this around the ansicolor plugin
  timestamps {
    ansiColor('xterm') {
      withEnv(mavenEnv) {
        cmd = ["${mavenHome}", mavenArgs.unique().join(' ')]
        
        cmd.push(defaultMavenSettings)
        // Running this inside try catch to generate reports in case of failures.
        try {
          // Run the final maven command.
          if(buildWithReleaseVersion) {
            // using the release version here.
            sh "${cmd.join(' ')} versions:set -DnewVersion=${project.version}"
          }

          sh "${cmd.join(' ')} ${mavenGoals}"
        } catch (Exception ex) {
          buildError = ex
          failedStatus = true
        } finally {
          if(junitTestReportsEnabled) {
            step([$class: 'JUnitResultArchiver', testResults: '**/target/surefire-reports/TEST-*.xml'])
            stash name: 'reports', includes: '**/target/surefire-reports/TEST-*.xml'
          }

          if(htmlReportsEnabled) {
            // publish html
            // snippet generator doesn't include "target:"
            // https://issues.jenkins-ci.org/browse/JENKINS-29711.
            def publishHtmlReportsConf  = [
              htmlReportTitle   : config.get('htmlReportTitle', 'HTML Report'),
              htmlReportDir     : config.get('htmlReportDir', 'target/surefire-reports/'),
              htmlReportFiles   : config.get('htmlReportFiles', 'index.html'),
              publishJsonReports: config.get('publishJsonReports', false),
              publishHtmlReports: config.get('publishHtmlReports', true),
            ]
            generateAndPublishReports(publishHtmlReportsConf)
            stash name: 'reports', includes: '**/target/surefire-reports/*'
          }
          
          if(cucumberTestReportsEnabled) {
            def publishCucumberReportsConf  = [
              htmlReportTitle   : config.get('htmlReportTitle', "Cucumber Report"),
              htmlReportDir     : config.get('htmlReportDir', ''),
              htmlReportFiles   : config.get('htmlReportFiles', null),
              publishJsonReports: config.get('publishJsonReports', true),
              publishHtmlReports: config.get('publishHtmlReports', true),
              // karate report file path
              fileIncludePattern: config.get('fileIncludePattern', '**/target/surefire-reports/*.json'),
              fileExcludePattern: config.get('fileExcludePattern', ''),
              parallelTesting   : config.get('parallelTesting', true),
            ]
            generateAndPublishReports(publishCucumberReportsConf)

            if(collectEvidenceFlag) {
              try {
                def testResults = []
                dir(testResultDir) {
                  def listTestfile = sh(script:"ls *.json", returnStdout: true)
                  def jsonFileNames = listTestfile.split("\\r?\\n");
                  for(int i = 0; i < jsonFileNames.length; i++) {
                    def testResult = readJSON file: jsonFileNames[i]
                    testResults.addAll(testResult)
                  }
                  config["testResults"] = testResults
                }
              } catch(Exception ex) {
                echo "No test results to add"
              }
            }

            stash name: 'reports', includes: '**/target/surefire-reports/*'
          }
          if(failedStatus) {
            throw buildError
          } else {
            // add data to evidence storage
            if(collectEvidenceFlag) {
              collectEvidence(config)
            }
          }
        }
      }
    }
  }
}

def generateAndPublishReports(config) {
  if(config.publishJsonReports) {
    step([
      $class              : 'CucumberReportPublisher',
      fileExcludePattern  : "${config.fileExcludePattern}",
      fileIncludePattern  : "${config.fileIncludePattern}",
      parallelTesting     : config.parallelTesting,
      ignoreFailedTests   : false,
      jenkinsBasePath     : '',
      jsonReportDirectory : '',
      missingFails        : false,
      pendingFails        : false,
      skippedFails        : false,
      undefinedFails      : false,
    ])
  }

  if(config.publishHtmlReports && config.htmlReportFiles) {
    publishHTML(target: [
      reportName            : "${config.htmlReportTitle}",
      reportDir             : "${config.htmlReportDir}",
      reportFiles           : "${config.htmlReportFiles}",
      keepAll               : false,
      allowMissing          : false,
      alwaysLinkToLastBuild : false,
    ])
  }
}

def collectEvidence(config) {
  try {
    def date = new Date()
    def project = new ProjectProperties()
    project.loadProjectProperties()
    def environment = 'snapshot'
    def gitProjectName = project['projectName'].split("-")
    def evidenceType = "MavenBuild"
    def lob = "Not Defined"
    if(config.environment) {
      environment = config.environment
    }
   
    def evidence = [
      data: [ 
        [
          scmUrl: project['projectUrl'],
          commitHash: project['commitHash'],
          branch: project['branch'],
          jenkinsUrl: env.BUILD_URL,
          buildNumber: env.BUILD_NUMBER,
          jobSubmitter: utils.getBuildUserId()
        ]
      ],
      recordCreateDate: date.format('yyyy-MM-dd HH:mm:ss')
    ]

    if(config.testResults) {
      evidence['data'][0]['testResults'] = config.testResults
    }

    if(env.LOB) {
      lob = env.LOB
    }
    
    def data = [
      applicationName: project['projectName'],
      applicationType: "service",
      evidenceType: evidenceType,
      carId: env.CARID,
      environment: environment,
      lineOfBusiness: lob,
      majorVersion: "1.0.${env.BUILD_NUMBER}",
      owner: env.OWNER,
      evidence: evidence
    ]

    config['data'] = utils.generateEvidenceData(data)
    evidenceStorage.add(config)
  } catch(Exception ex) {
    echo "WARN: unable to add evidence to evidence storage"
  }
}


return this;