import com.usbank.*
import groovy.json.JsonOutput

def call(Closure body) {
  def config = [:]
  body.resolveStrategy = Closure.DELEGATE_FIRST
  body.delegate = config
  body()
  add(config)
}

def add(config) {
  def pipelineProperties = new PipelineProperties()
  def endpointUrl = config.get('endpointUrl', pipelineProperties.get('evidence.storage.dev.url'))
  def endpoint = config.get('endpoint', '/usb/v1/evidence-storage/evidences')
  def data = config.get('data', [:])
  def apiConsumerKey = config.get('apiConsumerKey', pipelineProperties.get('evidence.storage.dev.api.consumer.key.id'))
  def response = null
  
  def httpRequestData = [
    httpMode: 'POST',
    url: "${endpointUrl}/${endpoint}",
    acceptType: 'APPLICATION_JSON',
    apiConsumerKey: apiConsumerKey,
    requestBody: data,
  ]
  try {
    httpRequestEvidenceEndpoint(httpRequestData)
  } catch(Exception ex) {
    echo "WARN: not able to upload evidence to evidence storage"
    println ex.toString()
    println ex.getStackTrace()
  }
}

// deprecating the use of OAuth token for evidence storage API
def generateToken(config) {
  def pipelineProperties = new PipelineProperties()
  def tokenEndpointUrl = config.get('tokenEndpointUrl', pipelineProperties.get('evidence.storage.dev.url'))
  def tokenEndpoint = config.get('tokenEndpoint', '/oauth_usb/generatetoken')
  def apiConsumerKey = config.get('apiConsumerKey', pipelineProperties.get('evidence.storage.dev.api.consumer.key.id'))
  def authorizationToken = config.get('authorizationToken', pipelineProperties.get('evidence.storage.dev.auth.token.id'))
  def proxyEnabled = config.get('proxyEnabled', false)
  def response = null

  def httpRequestData = [
    httpMode: 'POST',
    url: "${tokenEndpointUrl}/${tokenEndpoint}",
    acceptType: 'APPLICATION_JSON',
    validResponseCodes: '200'
  ]

  if (proxyEnabled) {
    httpRequestData['httpProxy'] = "${pipelineProperties.get('proxy.http.url')}"
  }

  withCredentials([string(credentialsId: authorizationToken, variable: 'AUTHTOKEN')]) {
    withCredentials([string(credentialsId: apiConsumerKey, variable: 'TOKEN')]) {
      httpRequestData['customHeaders'] = [[name:'Content-Type', value:"application/x-www-form-urlencoded;charset=utf-8"],
                                          [name:'Authorization', value:"Basic $AUTHTOKEN"],
                                          [name:'apikey', value: "$TOKEN"],
                                          [name:'grant_type', value:'client_credentials']]                          
      response = httpRequest(httpRequestData)
    }
  }
  jsonData = readJSON text: response.content.toString()
  return jsonData.access_token
}

def httpRequestEvidenceEndpoint(params) {
  // Escape comma, space, and quotes for shellout
  withCredentials([string(credentialsId: params.apiConsumerKey, variable: 'TOKEN')]) {
    def response = null
    def content = null
    def jsonContent = null
    def httpRequestData = [
      acceptType: 'APPLICATION_JSON', 
      contentType: 'APPLICATION_JSON', 
      httpMode: 'POST', 
      requestBody: JsonOutput.toJson(params.requestBody).toString(), 
      url: params.url,
      customHeaders: [[name: "apiKey", value: "${TOKEN}"]],
      validResponseCodes: '200,201'
    ]

    try {
      response = httpRequest(httpRequestData)
      content = response.content
      echo "INFO: ${content.toString()}"
      jsonContent = readJSON text: content.toString()
    } catch (Exception ex) {
      if (jsonContent.code && (jsonContent.code != 201)) {
        echo jsonContent.toString()
      }
      echo "WARN: data not inserted successfully"
      println ex.toString()
      println ex.getStackTrace()
    }
  }
}

return this;
