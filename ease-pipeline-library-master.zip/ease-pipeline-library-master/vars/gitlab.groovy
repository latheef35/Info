import com.usbank.*
import groovy.json.JsonOutput
import java.net.URLEncoder

def call(Closure body) {
  def config = [:]
  body.resolveStrategy = Closure.DELEGATE_FIRST
  body.delegate = config
  body()
  create(config)    
}

def create(config) {
  def gitLabFolderName = config.get('gitLabFolderName','')
  config['namespaceId'] = getGroupId(config)
  if (gitLabFolderName) {
    config['namespaceId'] = getNameSpaceId(config)
  } 

  def projectPayload = createRepository(config)
  def projectInfo = readJSON text: projectPayload
  config['projectId'] = projectInfo.id
  config['userNameId'] = getUserId(config)
  getAccessToProject(config)
}

def getGroupId(config=[:]) {
  def pipelineProperties = new PipelineProperties()
  def groupId = null
  def gitLabApiToken = config.get('gitlabApiToken', pipelineProperties.get('gitlab.api.token'))
  def gitLabApiUrl = config.get('gitLabApiUrl', pipelineProperties.get('gitlab.api.url'))
  def gitLabGroupName = config.get('gitLabGroupName','')

  if(!gitLabGroupName) {
    error "gitLabGroupName parameter is not defined"
  }

  withCredentials([string(credentialsId: gitLabApiToken, variable: 'TOKEN')]) {
    response = httpRequest(
      url: gitLabApiUrl + "/api/v4/groups?search=${gitLabGroupName}",
      httpMode: 'GET',
      customHeaders:[[name:'PRIVATE-TOKEN', value:"$TOKEN"]],
      acceptType: 'APPLICATION_JSON',
      validResponseCodes: '200'
    )
  }

  def groups = readJSON text: response.content.toString()

  for(element in groups){
    def group = readJSON text: element.toString()
    if(group.path == "${gitLabGroupName}") {
      groupId = group.id
      echo "Current group id is ${groupId} and the namespace full path ${group.path}"
    }
  }
  
  if(groupId == null) {
    error "No valid group id found for path ${gitLabGroupName}"
  }
  return groupId
}

def getNameSpaceId(config=[:]) {
  def pipelineProperties = new PipelineProperties()
  def namespaceId = null
  def gitLabApiToken = config.get('gitlabApiToken', pipelineProperties.get('gitlab.api.token'))
  def gitLabApiUrl = config.get('gitLabApiUrl', pipelineProperties.get('gitlab.api.url'))
  def gitLabGroupName = config.get('gitLabGroupName','')
  def gitLabFolderName = config.get('gitLabFolderName','')
  
  if(!gitLabFolderName) {
    error "gitLabFolderName parameter is not defined"
  }

  if(!gitLabGroupName) {
    error "gitLabGroupName parameter is not defined"
  }

  withCredentials([string(credentialsId: gitLabApiToken, variable: 'TOKEN')]) {
    response = httpRequest(
      url: gitLabApiUrl + "/api/v4/namespaces?search=${gitLabFolderName}",
      httpMode: 'GET',
      customHeaders:[[name:'PRIVATE-TOKEN', value:"$TOKEN"]],
      acceptType: 'APPLICATION_JSON',
      validResponseCodes: '200'
    )
  }
  
  def namespaces = readJSON text: response.content.toString()
  
  for(element in namespaces){
    def namespace = readJSON text: element.toString()
    if(namespace.full_path == "${gitLabGroupName}/${gitLabFolderName}") {
      namespaceId = namespace.id
      echo "Current namespace id is ${namespaceId} and the namespace full path ${namespace.full_path}"
    }
  }
  
  if(namespaceId == null) {
    error "No valid namespace id found for path ${gitLabGroupName}/${gitLabFolderName}"
  }

  return namespaceId
}

def createRepository(config=[:]) {
  def pipelineProperties = new PipelineProperties()
  def namespaceId = config.get('namespaceId', '')
  def gitLabApiToken = config.get('gitlabApiToken', pipelineProperties.get('gitlab.api.token'))
  def gitLabApiUrl = config.get('gitLabApiUrl', pipelineProperties.get('gitlab.api.url'))
  def projectName = config.get('projectName', '')
  def visibility = config.get('visibility', 'internal')
  def requestAccessEnabled = config.get('requestAccessEnabled', true)
  def payload = null
  
  timestamps {
    ansiColor('xterm') {
      if(!projectName) {
        error "projectName parameter is not defined"
      }

      def endpoint = "/api/v4/projects?name=${projectName}&visibility=${visibility}&request_access_enabled=${requestAccessEnabled}"
      if(namespaceId != null || namespaceId != '') {
        echo "namespaceId ${namespaceId} defined will create this repo under default location."
        endpoint = "/api/v4/projects?name=${projectName}&namespace_id=${namespaceId}&visibility=${visibility}&request_access_enabled=${requestAccessEnabled}"
      }

      withCredentials([string(credentialsId: gitLabApiToken, variable: 'TOKEN')]) {
        response = httpRequest(
          url: gitLabApiUrl + endpoint,
          httpMode: 'POST',
          customHeaders:[[name:'PRIVATE-TOKEN', value:"$TOKEN"]],
          validResponseCodes: '200,201'
        )
      }
      payload = readJSON text: response.content.toString()
      echo payload.toString()
      echo "Here is the link to the git repo: ${payload.http_url_to_repo}"
      echo "Here is the link to the git ssh repo: ${payload.ssh_url_to_repo}"
    }
  }
  return payload.toString()
}

def getUserId(config=[:]) {
  def pipelineProperties = new PipelineProperties()
  def gitLabUserName = config.get('gitLabUserName','')
  def gitLabApiToken = config.get('gitlabApiToken', pipelineProperties.get('gitlab.api.token'))
  def gitLabApiUrl = config.get('gitLabApiUrl', pipelineProperties.get('gitlab.api.url'))

  if(!gitLabUserName) {
    error "gitLabUserName parameter is not defined"
  }

  withCredentials([string(credentialsId: gitLabApiToken, variable: 'TOKEN')]) {
    response = httpRequest(
      url: gitLabApiUrl + "/api/v4/users?username=${gitLabUserName}",
      httpMode: 'GET',
      customHeaders:[[name:'PRIVATE-TOKEN', value:"$TOKEN"]],
      acceptType: 'APPLICATION_JSON',
      validResponseCodes: '200'
    )
  }

  def userNameInfo = readJSON text: response.content.toString()
  def userNameId = userNameInfo.id

  if(userNameId == null) {
    error "User name ID is not valid"
  }

  return userNameId
}

def getAccessToProject(config=[:]) {
  def pipelineProperties = new PipelineProperties()
  def gitLabApiToken = config.get('gitlabApiToken', pipelineProperties.get('gitlab.api.token'))
  def gitLabApiUrl = config.get('gitLabApiUrl', pipelineProperties.get('gitlab.api.url'))
  def userNameId = config.get('userNameId', '')
  def projectId = config.get('projectId', '')
  def accessLevel = config.get('accessLevel', 30)

  if(!userNameId) {
    error "userNameId parameter is not defined"
  }

  if(!projectId) {
    error "projectId parameter is not defined"
  }
  
  def endpoint = "/api/v4/projects/${projectId}/members?user_id=${userNameId[0].toString()}&access_level=${accessLevel}"
  withCredentials([string(credentialsId: gitLabApiToken, variable: 'TOKEN')]) {
    response = httpRequest(
      url: gitLabApiUrl + endpoint,
      httpMode: 'POST',
      customHeaders:[[name:'PRIVATE-TOKEN', value:"$TOKEN"]],
      validResponseCodes: '200,201'
    )
  }
}

def getProjectId(config=[:]) {
  def pipelineProperties = new PipelineProperties()
  def projectId = null
  def gitLabApiToken = config.get('gitlabApiToken', pipelineProperties.get('gitlab.api.token'))
  def gitLabApiUrl = config.get('gitLabApiUrl', pipelineProperties.get('gitlab.api.url'))
  def gitLabProjectName = config.get('gitLabProjectName','')
  def gitLabProjectUrl = config.get('gitLabProjectUrl','')

  if(!gitLabProjectName) {
    error "gitLabProjectName parameter is not defined"
  }

  if(!gitLabProjectUrl) {
    error "gitLabProjectUrl parameter is not defined"
  }

  withCredentials([string(credentialsId: gitLabApiToken, variable: 'TOKEN')]) {
    response = httpRequest(
      url: gitLabApiUrl + "/api/v4/projects?search=${gitLabProjectName}",
      httpMode: 'GET',
      customHeaders:[[name:'PRIVATE-TOKEN', value:"$TOKEN"]],
      acceptType: 'APPLICATION_JSON',
      validResponseCodes: '200'
    )
  }

  def projects = readJSON text: response.content.toString()

  for(element in projects) {
    echo element.toString()
    def project = readJSON text: element.toString()

    if(project.path.toString() == gitLabProjectName.trim().toString() && project.http_url_to_repo.toString().contains(gitLabProjectUrl)) {
      projectId = project.id
      echo "Current project id is ${projectId} and the namespace full path ${project.path}"
    }
  }
  
  if(projectId == null) {
    error "No valid project id found for path ${projectId}"
  }
  return projectId
}

def tagProject(config=[:]) {
  def pipelineProperties = new PipelineProperties()
  def gitLabApiToken = config.get('gitlabApiToken', pipelineProperties.get('gitlab.api.token'))
  def gitLabApiUrl = config.get('gitLabApiUrl', pipelineProperties.get('gitlab.api.url'))
  def gitTagName = config.get('gitTagName', '')
  def gitCommitHash = config.get('gitCommitHash', '')
  def now = new Date()
  def finalDate = now.format("yyyy-MM-dd HH:mm:ss.SSS")

  if(!gitTagName) {
    error "gitTagName parameter is not defined"
  }

  if(!gitCommitHash) {
    error "gitCommitHash parameter is not defined"
  }

  def gitTagMessage = config.get('gitTagMessage', "Creating a Release Tag ${gitTagName} on date ${finalDate}")
  def gitReleaseDescription = config.get('gitReleaseDescription', "Tagging the branch with production release tag and date create: ${finalDate}")
  def projectId = getProjectId(config)

  // Note encoding the params since it can have wild card character.
  withCredentials([string(credentialsId: gitLabApiToken, variable: 'TOKEN')]) {
    response = httpRequest(
      url: gitLabApiUrl + "/api/v4/projects/${projectId}/repository/tags?tag_name=" + URLEncoder.encode(gitTagName) + "&ref=" + URLEncoder.encode(gitCommitHash) + "&message=" + URLEncoder.encode(gitTagMessage,"UTF-8") + "&release_description=" + URLEncoder.encode(gitReleaseDescription,"UTF-8"),
      httpMode: 'POST',
      customHeaders:[[name:'PRIVATE-TOKEN', value:"$TOKEN"]],
      acceptType: 'APPLICATION_JSON_UTF8',
      contentType: 'APPLICATION_JSON_UTF8',
      validResponseCodes: '201,200'
    )
  }
  
  echo "INFO: Project tagged successfully with Tagname: ${gitTagName} and CommitHash: ${gitCommitHash}"
}

return this;
