import com.usbank.*

def call(Closure body) {
  def config = [:]
  body.resolveStrategy = Closure.DELEGATE_FIRST
  body.delegate = config
  body()
  run(config)    
}

def run(config) {
  def pipelineProperties = new PipelineProperties()

  def proxyEnv = [
    proxyHost: pipelineProperties.get('proxy.host'),
    proxyPort: pipelineProperties.get('proxy.port'),
  ]

  def gradleHome = config.get('gradleHome', pipelineProperties.get('gradle.home'))
  def gradleGoals = config.get('gradleGoals', 'clean test')
  def proxyEnabled = config.get('proxyEnabled', false)
  def defaultProxy = config.get('defaultProxy', proxyEnv)
  timestamps {
    ansiColor('xterm') {
      if(proxyEnabled) {
        withEnv(defaultProxy) {
          sh "${gradleHome} ${gradleGoals}"
        }
      } else {
        sh "${gradleHome} ${gradleGoals}"
      }
    }
  }
}

return this;
