import com.usbank.*;

// This module task consist of the common helper fuctions
def normalizeEnv(env) {
  switch(env.toLowerCase().trim()) {
    // added this switch in case in future we need more env
    case ~/(sandbox|sb)/: //added this case to handle kubernetes deployments
      return 'sandbox'
    case 'it': //added this case to handle kubernetes deployments
      return 'it'
    case ~/.*(alpha).*/:
      return 'alpha'
    case ~/.*(uat|qa).*/:
      return 'uat'
    case ~/.*(prod|production|cert).*/:
      return 'prod'
    default:
      return 'dev'
  }
}

def checkIfOnPrem(env) {
  def onprem = false
  if(env.contains('onprem')) {
    onprem = true
  }
  env = normalizeEnv(env)
  if(onprem) {
    env = 'onprem.' + env
  }
  return env
}

def generateApigeeToken(args=[:]) {
  def pipelineProperties = new PipelineProperties()
  def env = args.get('env','')
  def credentialsId = args.get('credentialsId', pipelineProperties.get('apigee.credential.id'))
  def apigeeOauthCredentialsId = args.get('apigeeOauthCredentialsId', pipelineProperties.get('apigee.token.id'))
  def config = null
  def response = null
  def proxyEnabled = args.get('proxyEnabled', true)
  
  if(!env) {
    error "env is the required parameter - it can be dev|uat|alpha|prod"
  }

  env = checkIfOnPrem(env)
  def url = pipelineProperties.getApigeeTokenUrl(env)
  
  echo "INFO: Generating token for environment ${env}"
  
  def httpRequestData = [
    httpMode: 'POST',
    url: url,
    acceptType: 'APPLICATION_JSON',
    validResponseCodes: '200,201'
  ]

  if (proxyEnabled) {
    httpRequestData['httpProxy'] = "${pipelineProperties.get('proxy.http.url')}"
  }

  // TODO wrap this around ansicolor
  if(credentialsId) {
    withCredentials([usernamePassword(credentialsId: credentialsId.toString(),
                      usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD')]) {
      withCredentials([string(credentialsId: apigeeOauthCredentialsId.toString(), variable: 'TOKEN')]) {
        httpRequestData['requestBody'] = "grant_type=password&username=$USERNAME&password=$PASSWORD"
        httpRequestData['customHeaders'] = [[name:'Content-Type', value:"application/x-www-form-urlencoded;charset=utf-8"],
                                            [name:'Authorization', value:"Basic $TOKEN"]]
        response = httpRequest(httpRequestData)
      }
      config = readJSON text: response.content.toString()
    }
  }
  
  return config.access_token
}

def getProxyArtifactName(mavenApigeePluginVersion) {
  def pom = readMavenPom()
  if(mavenApigeePluginVersion == "1.1.5") {
    return sprintf('%s%s', [pom.artifactId, pom.version])
  } else {
    return sprintf('%s-%s', [pom.artifactId, pom.version])
  }
}

def getVersionedProxyArtifactName() {
  def pom = readMavenPom()
  return sprintf('%s-%s', [pom.artifactId, pom.version])
}

def validateChangeNumberAndTaskId(args=[:]) {
  def pipelineProperties = new PipelineProperties()
  def itsmCredentialsId = args.get('itsmCredentialsId', pipelineProperties.get('itsm.credentials.id'))
  def taskId = args.taskId
  def changeTicketNumber = args.changeTicketNumber

  if(!changeTicketNumber) {
    error "changeTicketNumber is the required field for the the validation"
  }
  
  if(!taskId) {
    error "taskId is the required field for the the validation"
  }

  def istmUrl = args.get('istmUrl', pipelineProperties.get('itsm.url'))
  def endPoint = istmUrl + "" + "/doc-itsm-ctasks/_search?q=_id:${taskId}&pretty"

  def response = httpRequest(
    url: endPoint,
    authentication: itsmCredentialsId.toString(),
    httpMode: 'GET',
    acceptType: 'APPLICATION_JSON',
    validResponseCodes: '200'
  )
  
  def taskIdPayload = readJSON text: response.content.toString()
  
  if (taskIdPayload.hits.hits.size() < 1) {
    error "taskIdPayload is empty ${taskIdPayload.hits.hits.toString()} either the change order or the taskid is invalid."  
  }
  
  def taskIdPayloadHits = readJSON text: taskIdPayload.hits.hits[0].toString()
  def payLoadTaskId = taskIdPayloadHits._source.taskid.toString()
  def payloadChangeTicketNumber = taskIdPayloadHits._source.parentchange.toString()
  def phase = taskIdPayloadHits._source.phase.toString()
  
  if (payLoadTaskId != taskId && payloadChangeTicketNumber != changeTicketNumber) {
    error "Provided Change Ticket number: ${changeTicketNumber} did not match the payloadChangeTicketNumber: ${payloadChangeTicketNumber} or provided Task id ${taskId} did not match the payLoadTaskId: ${payLoadTaskId}"  
  }
  echo "The current task id phase is ${phase} for task id: ${taskId}"
}

def uploadArtifactsToArtifactory(args=[:]) {
  def pipelineProperties = new PipelineProperties()
  def credentialsId = args.get('credentialsId', pipelineProperties.get('artifactory.credential.id'))
  def artifactoryUrl = args.get('artifactoryUrl', pipelineProperties.get('artifactory.url'))
  def changeDir = args.changeDir ?: '.'
  def baseDir = changeDir.split('/')
  def pomDir = args.get('pomDir', baseDir[0])
  def artifactName = args.get('artifactName', null)
  def artifactType = args.get('artifactType', 'zip')
  def isProxyArtifact = args.get('isProxyArtifact', true)
  def versionedArtifactName = null
  def mavenApigeePluginVersion = null
  
  if(!args.env) {
    error "env required parameter not defined"
  }

  if(!credentialsId) {
    error "credentialsId not defined"
  }
  
  if(isProxyArtifact) {
    def commonParentPomPath = args.get('commonParentPomPath', 'common/parent-pom')
    dir(commonParentPomPath) {
     def parentPomObject = readMavenPom file: 'parent-apiproxy-pom.xml'
     mavenApigeePluginVersion = parentPomObject.build.plugins[1].version
    }
    dir(pomDir) {
      if(mavenApigeePluginVersion == "1.1.5") {
        artifactName = sprintf('%s-%s.%s', [getProxyArtifactName(mavenApigeePluginVersion), args.env, artifactType])
      } else {
        artifactName = sprintf('%s.%s',[getProxyArtifactName(mavenApigeePluginVersion), artifactType])
      }
      versionedArtifactName = artifactName
      if(isProxyArtifact) {
        versionedArtifactName = sprintf('%s-%s.%s', [getVersionedProxyArtifactName() + '.' + env.BUILD_NUMBER, args.env, artifactType])
      }
    }
  } else {
    versionedArtifactName = artifactName
  }
  
  dir(changeDir) {
    if(isProxyArtifact) {
      copyProxyArtifact(artifactName, versionedArtifactName)
      args['versionedArtifactName'] = versionedArtifactName
      artifactoryCall(args)
    } else {
      args['versionedArtifactName'] = versionedArtifactName
      artifactoryCall(args)
    }
  }
}

def artifactoryCall(args=[:]) {
  def pipelineProperties = new PipelineProperties()
  def credentialsId = args.get('credentialsId', pipelineProperties.get('artifactory.credential.id'))
  def artifactoryUrl = args.get('artifactoryUrl', pipelineProperties.get('artifactory.url'))
  withCredentials([usernameColonPassword(credentialsId: credentialsId.toString(), variable: 'USERPASS')]) {
    sh(script: " curl -u $USERPASS -X PUT ${artifactoryUrl} -T ${args.versionedArtifactName}", returnStdout: true)
  }
}

def getKubernetesCredentialId(namespace) {
  def k8sConfig = libraryResource 'kubernetes-credential-config.yaml'
  def k8sCreds = readYaml text: k8sConfig.toString()
  return k8sCreds[namespace]['kubernetes-credential-id']
}

def copyProxyArtifact(artifactName, newArtifactName) {
  sh(script: "cp ${artifactName} ${newArtifactName}", returnStdout: true)
}

def generateEvidenceData(config) {
  def dataObject = [:]
  
  if (!config.carId) {
    config['carId'] = 0
  }

  def data = [
    applicationName: config.applicationName,
    applicationType: config.applicationType,
    evidenceType: config.evidenceType,
    carId: config.carId,
    environment: config.environment,
    lineOfBusiness: config.lineOfBusiness,
    majorVersion: config.majorVersion,
    owner: config.owner
  ]
  
  if(config.evidence) {
    dataObject = data + [evidence: config.evidence]
  }

  return dataObject
}

def getBuildUserId() {
  def userId = null
  wrap([$class: 'BuildUser']) {
    userId = env.BUILD_USER_ID
  }
  return userId
}

return this;
