import com.usbank.*

def call(Closure body) {
  def config = [:]
  body.resolveStrategy = Closure.DELEGATE_FIRST
  body.delegate = config
  body()
  build(config)    
}

def build(config) {
  def environment = config.get('env', 'dev')
  environment = utils.normalizeEnv(environment)
  def timeOutDuration = config.get('timeOutDuration', 5)
  def changeDir = config.changeDir ?: '.'

  // always setting the proxy to true
  config['proxyEnabled'] = config.get('proxyEnabled', true)
  config['buildWithReleaseVersion'] = config.get('buildWithReleaseVersion', false)

  // adding this logic to not ask for input prompt multiple times
  if(environment != 'dev' && environment != '' && environment != null) {
    if(!env.CHANGE_TICKET_NUMBER_ALPHA && !env.CHANGE_TICKET_TASK_ID_ALPHA && environment == 'alpha') {
      validateInput(environment, timeOutDuration)
    }
    
    if(!env.CHANGE_TICKET_NUMBER_ALPHA && !env.CHANGE_TICKET_TASK_ID_ALPHA && environment == 'uat') {
      validateInput(environment, timeOutDuration)
    }

    if(!env.CHANGE_TICKET_NUMBER_PROD && !env.CHANGE_TICKET_TASK_ID_PROD && environment == 'prod') {
      validateInput(environment, timeOutDuration)
    } 
  }
  config['collectEvidence'] = false
  dir(changeDir) {
    // running the apigee build
    mvnBuild.run(config)
  }
  collectEvidence(config)
}

def validateInput(environment, timeOutDuration) {
  def changeTicketNumber = null
  timeout(time: timeOutDuration, units: 'MINUTES') {
    changeTicketNumber = input(
      id: 'userInput', message: 'Please provide the change ticket number to proceed', parameters: [
      string([defaultValue: '', description: 'Change Ticket is required for auditing of this pipeline', name: 'Change Ticket Number: ']),
      string([defaultValue: '', description: 'Change Ticket Task id is required for auditing of this pipeline', name: 'Change Ticket Task Id: ']
    )])
  }

  def changeTicket = changeTicketNumber['Change Ticket Number: '].trim()
  def taskId = changeTicketNumber['Change Ticket Task Id: '].trim()

  // if(changeTicket ==~ /(C\d+)/ && taskId ==~ /(T\d+)/) {
    // utils.validateChangeNumberAndTaskId([taskId:taskId, changeTicketNumber: changeTicket])
    if(environment == 'alpha' || environment == 'uat') {
      env.CHANGE_TICKET_NUMBER_ALPHA = changeTicket
      env.CHANGE_TICKET_TASK_ID_ALPHA = taskId
    } else {
      env.CHANGE_TICKET_NUMBER_PROD = changeTicket
      env.CHANGE_TICKET_TASK_ID_PROD = taskId
    }
    echo "Promoting artifacts to following environment: ${environment} with changeTicketNumber: ${changeTicket} and taskId: ${taskId}" 
//   } else {
//     error "changeTicketNumber: ${changeTicket} or taskId: ${taskId} is invalid or not specified, which is a mandatory field for audit purpose."
//   }
}

def collectEvidence(config) {
  try {
    def date = new Date()
    def proxyProject = new ProjectProperties()
    proxyProject.loadProjectProperties()
    def nonNormalizedEnv = config.env
    def environment = utils.normalizeEnv(nonNormalizedEnv)
    def gitProjectName = proxyProject['projectName'].split("-")
    def url = proxyProject['projectUrl']
    def urlSplit = url.split('/')

    if (nonNormalizedEnv.contains("it")) {
      nonNormalizedEnv = "it"  
    } else {
      nonNormalizedEnv = utils.normalizeEnv(nonNormalizedEnv)
    }
   
    def evidence = [
      data: [ 
        [
          scmUrl: proxyProject['projectUrl'],
          commitHash: proxyProject['commitHash'],
          branch: proxyProject['branch'],
          jenkinsUrl: env.BUILD_URL,
          buildNumber: env.BUILD_NUMBER,
          jobSubmitter: utils.getBuildUserId(),
          componentType: config.changeDir,
          componentDeployed: config.mavenGoals 
        ]
      ],
      recordCreateDate: date.format('yyyy-MM-dd HH:mm:ss')
    ]
    
    def data = [
      applicationName: proxyProject['projectName'],
      applicationType: gitProjectName[1].toLowerCase(),
      evidenceType: "MavenApigeeBuild",
      carId: env.CARID,
      environment: nonNormalizedEnv,
      lineOfBusiness: urlSplit[4].toLowerCase(),
      majorVersion: "1.0.${env.BUILD_NUMBER}",
      owner: env.OWNER,
      evidence: evidence
    ]

    if (environment == 'alpha') {
      evidence['data'][0]['changeTicketNumber'] = env.CHANGE_TICKET_NUMBER_ALPHA
      evidence['data'][0]['changeTaskId'] = env.CHANGE_TICKET_TASK_ID_ALPHA
      evidence['data'][0]['taggedVersion'] = "1.0.${env.BUILD_NUMBER}"
    } 

    if (environment == 'prod') {
      evidence['data'][0]['changeTicketNumber'] = env.CHANGE_TICKET_NUMBER_PROD
      evidence['data'][0]['changeTaskId'] = env.CHANGE_TICKET_TASK_ID_PROD
      evidence['data'][0]['taggedVersion'] = "1.0.${env.BUILD_NUMBER}"
    }

    config['data'] = utils.generateEvidenceData(data)
    evidenceStorage.add(config)
  } catch(Exception ex) {
    echo "WARN: unable to add evidence to evidence storage"
  }
}

return this;
