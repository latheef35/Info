import com.usbank.*

def call(Closure body) {
  def config = [:]
  body.resolveStrategy = Closure.DELEGATE_FIRST
  body.delegate = config
  body()
  execute(config)    
}

def execute(config) {
  def pipelineProperties = new PipelineProperties()
  def sonarUrl = config.get('sonarUrl', pipelineProperties.get('sonar.host.url'))
  def projectKey = config.get('projectKey', '')
  def applicationName = config.get('applicationName', '')
  def projectVersion = config.get('projectVersion', '')
  def sonarEncoding = config.get('sonarEncoding', pipelineProperties.get('sonar.encoding'))
  def sonarLogin = config.get('sonarLogin', pipelineProperties.get('sonar.credential.id'))
  // this feature is deprecated with the latest version of sonar qube
  // https://stackoverflow.com/questions/36347106/sonar-qualitygate-is-deprecated-in-sonar-qube-5-3-what-is-the-alternative
  def sonarQualityGate = config.get('sonarQualityGate', pipelineProperties.get('sonar.quality.gate'))
  def sonarQualityProfile = config.get('sonarQualityProfile',pipelineProperties.get('sonar.quality.profile'))
  def sonarDir = config.get('sonarDir', '.')
  def sonarArgs = config.get('sonarArgs', [])
  def sonarRequiredArgs = []
  def sonarCommand = []
  def sonarIssueReportOnConsole = config.get('sonarIssueReportOnConsole', true)
  def sonarHtmlReport = config.get('sonarHtmlReport', true)
  def sonarJsonReport = config.get('sonarJsonReport', "sonar.json")
  
  if(!projectKey) {
    error "projectKey is not defined"
  }

  if(!applicationName) {
    error "applicationName is not defined"
  }

  if(!projectVersion) {
    error "projectVersion is not defined"
  }

  sonarRequiredArgs = [
    "-Dsonar.host.url=${sonarUrl}",
    "-Dsonar.projectKey=${projectKey}",
    "-Dsonar.projectName=${applicationName}",
    "-Dsonar.projectVersion=${projectVersion}",
    "-Dsonar.sources=${sonarDir}",
    "-Dsonar.sonarEncoding=${sonarEncoding}",
    "-Dsonar.login=${sonarLogin}",
    "-Dsonar.profile=${sonarQualityProfile}",
    "-Dsonar.issuesReport.console.enable=${sonarIssueReportOnConsole}",
    "-Dsonar.issuesReport.html.enable=${sonarHtmlReport}",
    "-Dsonar.report.export.path=${sonarJsonReport}"
  ]

  sonarCommand.addAll(["sonar-scanner"])
  sonarRequiredArgs.addAll(sonarArgs)
  sonarCommand.addAll(sonarRequiredArgs)
  
  timestamps {
    ansiColor('xterm') {
      genericScan(sonarCommand)
      collectEvidence(config)
    }
  }
}

def genericScan(command) {
  //to save the logs and get the report url
  sh """
    ${command.join(' ')} &> temp.log
    cat temp.log
  """
}

def mavenSonarScan() {
  // TO DO implement the logic for maven sonar scan
}

def getJsonObject(config) {
  //get the report url and sonarqube url from the temp.log file
  def resultUrl = sh(script:"cat temp.log | grep 'More about the report processing'",returnStdout:true).split("at")[1].trim()
  def sonarUrl = sh(script:"cat temp.log | grep 'ANALYSIS SUCCESSFUL'",returnStdout:true).split("browse")[1].trim()
  def response = sh(script:"curl -u ${config.sonarLogin} -X GET ${resultUrl}",returnStdout:true).trim()
  def sonarResult = readJSON text: response.toString()
  config['sonarUrl'] = sonarUrl
  config['sonarStatus'] = sonarResult.task.status
  config['sonarResult'] = sonarResult
}

def collectEvidence(config) {
  try {
    def project = new ProjectProperties()
    project.loadProjectProperties()
    getJsonObject(config)
    def date = new Date()
    def environment = 'dev'
    def defaultApplicationType = 'service'
    def lob = env.LOB
    def url = project['projectUrl']
    def urlSplit = url.split('/')

    def evidence = [
      data: [ 
        [
          scmUrl: project['projectUrl'],
          commitHash: project['commitHash'],
          branch: project['branch'],
          jenkinsUrl: env.BUILD_URL,
          buildNumber: env.BUILD_NUMBER,
          jobSubmitter: utils.getBuildUserId(),
          sonarUrl: config.sonarUrl,
          sonarStatus: config.sonarStatus,
          sonarResult: config.sonarResult
        ]
      ],
      recordCreateDate: date.format('yyyy-MM-dd HH:mm:ss')
    ]

    if (project['projectName'].toString().contains("proxy")) {
       defaultApplicationType = "proxy"
       lob = urlSplit[4].toLowerCase()
    } 
    
    if (project['projectName'].toString().toLowerCase().contains("sharedflow")) {
       defaultApplicationType = "sharedflow"
       lob = urlSplit[4].toLowerCase()
    }
    
    def data = [
      applicationName: project['projectName'],
      applicationType: defaultApplicationType,
      evidenceType: "SonarScan",
      carId: env.CARID,
      environment: environment,
      lineOfBusiness: lob,
      majorVersion: "1.0.${env.BUILD_NUMBER}",
      owner: env.OWNER,
      evidence: evidence
    ]

    config['data'] = utils.generateEvidenceData(data)
    evidenceStorage.add(config)
  } catch(Exception ex) {
    echo "WARN: unable to add evidence to evidence storage"
  }
}
return this;