import com.usbank.*

def call(Closure body) {
  def config = [:]
  body.resolveStrategy = Closure.DELEGATE_FIRST
  body.delegate = config
  body()
  run(config)    
}

def run(config) {
  def pipelineProperties = new PipelineProperties()
  def k8sHelper = new K8sHelper()

  def k8sConf = [:]
  def k8sStandardConfig = [
    kubectlArgs: config.get('kubectlArgs', 'get pods'),
    deployEnv: config.get('deployEnv', 'sandbox'),
    deploymentType: config.get('deploymentType', ''),
    deploymentVersion: config.get('deploymentVersion', "1.0.${env.BUILD_NUMBER}"),
    deploymentFileName: config.get('deploymentFileName', 'deployment.yaml'),
    serviceFileName: config.get('serviceFileName', 'service.yaml'),
    ingressFileName: config.get('ingressFileName', 'ingress.yaml'),
    persistantVolumeFileName: config.get('persistantVolumeFileName', 'persistentvolume.yaml'),
    persistantVolumeClaimFileName: config.get('persistantVolumeClaimFileName', 'persistentvolumeclaim.yaml'),
    timeOutDuration: config.get('timeOutDuration', 5),
    kubectlNamespace: config.get('kubectlNamespace', 'ease'),
    createService: config.get('createService', true),
    createIngress: config.get('createIngress', true),
    createPersistentVolume: config.get('createPersistentVolume', false),
    createPersistentVolumeClaim: config.get('createPersistentVolumeClaim', false),
    dockerRegistry: config.get('dockerRegistry', pipelineProperties.get('usb.docker.registry')),
    namespace: config.get('namespace', pipelineProperties.get('usb.docker.namespace')),
    imageName: config.get('imageName', []),
  ]
  
  k8sStandardConfig['kubectlConfCredentialsId'] = utils.getKubernetesCredentialId(k8sStandardConfig.kubectlNamespace)
  echo "using ${k8sStandardConfig.kubectlConfCredentialsId} and deploying to namespace: ${k8sStandardConfig.kubectlNamespace}"

  k8sStandardConfig['noramlizedEnv'] = utils.normalizeEnv(k8sStandardConfig.deployEnv)
  
  k8sConf.putAll(k8sStandardConfig)

  if(!k8sStandardConfig.deployEnv) {
    error "deployEnv not defined can be prod/uat/it/dev/sandbox"
  }
  
  if(!k8sStandardConfig.deploymentType) {
    error "deploymentType not defined can be bluegreenswitch/deploygreen/rollback/deleteblue"
  }

  if(k8sStandardConfig.kubectlConfCredentialsId == null) {
    error "please provide the correct kubectlConfCredentialsId"
  }

  if(k8sStandardConfig.imageName.size() < 1) {
    error "imageName not defined can be prod/uat/it/dev/sandbox"
  }
  
  // Note: this needs to be updated incase if we need to have this only for prod
  if(k8sStandardConfig.noramlizedEnv == 'prod' || k8sStandardConfig.noramlizedEnv == 'uat') {
    if(!env.CHANGE_TICKET_NUMBER_ALPHA && !env.CHANGE_TICKET_TASK_ID_ALPHA && k8sStandardConfig.noramlizedEnv == 'uat') {
       mvnBuildApigee.validateInput(k8sStandardConfig.noramlizedEnv, k8sStandardConfig.timeOutDuration)
    }

    if(!env.CHANGE_TICKET_NUMBER_PROD && !env.CHANGE_TICKET_TASK_ID_PROD && k8sStandardConfig.noramlizedEnv == 'prod') {
       mvnBuildApigee.validateInput(k8sStandardConfig.noramlizedEnv, k8sStandardConfig.timeOutDuration)
    }
  }
  
  if(k8sStandardConfig.deploymentType == "deploygreen") {
    stage "Create ${k8sStandardConfig.noramlizedEnv} green deployment"

    if(k8sStandardConfig.createPersistentVolume) {
      echo "Create/Update ${k8sStandardConfig.noramlizedEnv} persistant volume"
      k8sHelper.createPersistentVolume(k8sStandardConfig)
    }

    if(k8sStandardConfig.createPersistentVolumeClaim) {
      echo "Create/Update ${k8sStandardConfig.noramlizedEnv} persistant volume claim"
      k8sHelper.createPersistentVolumeClaim(k8sStandardConfig)
    }

    k8sHelper.createAndVerifyGreenDeployment(k8sStandardConfig)

    stage "Create/Update ${k8sStandardConfig.noramlizedEnv} service"
    k8sHelper.createService(k8sStandardConfig)

    if(k8sStandardConfig.createIngress) {
      echo "Create/Update ${k8sStandardConfig.noramlizedEnv} ingress rule"
      k8sHelper.createIngress(k8sStandardConfig)
    }
  }
  
  if(k8sStandardConfig.deploymentType == "bluegreenswitch") {
    stage "Blue Green switch for ${k8sStandardConfig.noramlizedEnv}"
    k8sHelper.goLive(k8sStandardConfig)
  }
  
  if(k8sStandardConfig.deploymentType == "rollback") {
    stage "Rollback for ${k8sStandardConfig.noramlizedEnv}"  
    k8sHelper.rollBackDeployment(k8sStandardConfig)
  }
  
  if(k8sStandardConfig.deploymentType == "deleteblue") {
    def blueStatus = k8sHelper.checkIfBlueExist(k8sStandardConfig)
    if(blueStatus) {
      stage "Delete blue deployment for ${k8sStandardConfig.noramlizedEnv}"
      k8sHelper.deleteBlueDeployment(k8sStandardConfig)
    }
  }
}

return this;
