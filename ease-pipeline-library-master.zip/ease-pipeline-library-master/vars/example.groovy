import com.usbank.*

def call(Closure body) {
  def config = [:]
  body.resolveStrategy = Closure.DELEGATE_FIRST
  body.delegate = config
  body()
  run(config)    
}

def run(config) {
  def message = config.get('message', '******no message set******');
  timestamps {
    ansiColor('xterm') {
      echo message
    }
  }
}

return this;
