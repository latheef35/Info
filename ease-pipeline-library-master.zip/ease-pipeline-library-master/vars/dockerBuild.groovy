import com.usbank.*

def call(Closure body) {
  def config = [:]
  body.resolveStrategy = Closure.DELEGATE_FIRST
  body.delegate = config
  body()
  run(config)    
}

def run(config) {
  def pipelineProperties = new PipelineProperties()
  def dockerConf = [:]
  def standardConfig = [
    dockerRegistry: config.get('dockerRegistry', pipelineProperties.get('usb.docker.registry')),
    namespace: config.get('namespace', pipelineProperties.get('usb.docker.namespace')),
    tagLatest: config.get('tagLatest', true),
    pushImage: config.get('pushImage', true),
    dir: config.get('dir', pwd()),
  ]
  
  dockerConf.putAll(config)
  if(!config.name) {
    error "docker image name not defined"
  }

  if(!config.version) {
    error "docker image version not defined"
  }
  
  dockerConf.putAll(standardConfig)
  def dockerCmd = ['docker', 'build', '--pull']
  timestamps {
    ansiColor('xterm') {
      dir(dockerConf.dir) {
        docker.withRegistry("https://${dockerConf.dockerRegistry}") {
          if (dockerConf.dockerfile) {
            dockerCmd.addAll(['-f', "${dockerConf.dockerfile}"])
          }

          dockerCmd.addAll(['-t', "${dockerConf.namespace}/${dockerConf.name}", "."])
          sh dockerCmd.join(' ')

          def dockerImage = docker.image("${dockerConf.namespace}/${dockerConf.name}")

          if (dockerConf.pushImage) {
            retry(3) {
              dockerImage.push(dockerConf.version)
              if (dockerConf.tagLatest && dockerConf.version != 'latest') {
                dockerImage.push('latest')
              }
            }
          }
          collectEvidence(config)
        }
      }
    }
  }
}

def collectEvidence(config) {
  try {
    def project = new ProjectProperties()
    project.loadProjectProperties()
    def date = new Date()
    def environment = 'prod'
    def lob = "Not Defined"

    if(config.tagLatest) {
      environment = 'non-prod'
    }

    def evidence = [
      data: [ 
        [
          scmUrl: project['projectUrl'],
          commitHash: project['commitHash'],
          branch: project['branch'],
          jenkinsUrl: env.BUILD_URL,
          buildNumber: env.BUILD_NUMBER,
          jobSubmitter: utils.getBuildUserId(),
          containerName: config.name,
          namespace: config.namespace
        ]
      ],
      recordCreateDate: date.format('yyyy-MM-dd HH:mm:ss')
    ]
    
    if(env.LOB) {
      lob = env.LOB   
    }

    def data = [
      applicationName: project['projectName'],
      applicationType: "service",
      evidenceType: "DockerBuild",
      carId: env.CARID,
      environment: environment,
      lineOfBusiness: lob.toLowerCase(),
      majorVersion: config.version,
      owner: env.OWNER,
      evidence: evidence
    ]

    config['data'] = utils.generateEvidenceData(data)
    evidenceStorage.add(config)
  } catch(Exception ex) {
    echo "WARN: unable to add evidence to evidence storage"
  }
}

return this;
