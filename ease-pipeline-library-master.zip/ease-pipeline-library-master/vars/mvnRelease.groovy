import com.usbank.*

def call(Closure body) {
  Map config = [:]
  body.resolveStrategy = Closure.DELEGATE_FIRST
  body.delegate = config
  body()
  call(config)
}

def call(Map config = [:]) {
  def pipelineProperties = new PipelineProperties()
  def project = new ProjectProperties()

  def proxyEnv = [
    proxyHost: pipelineProperties.get('proxy.host'),
    proxyPort: pipelineProperties.get('proxy.port'),
  ]

  // checking branch to make sure its master
  if (env.BRANCH_NAME && env.BRANCH_NAME != 'master') {
    error "maven releases can only be performed from the master branch"
  }
  
  def mavenHome = config.get('mavenHome', pipelineProperties.get('maven.home'))
  def mvnGoals = config.get("mvnGoals",[ "-Dmaven.repo.local=${pwd()}/.repository", "clean", "deploy"])
  def withDockerBuild = config.get('withDockerBuild', false)
  def skipIntegrationTests = config.get('skipIntegrationTests', true)
  def skipTests = config.get('skipTests', true)
  def skipMavenJavaDoc = config.get('skipMavenJavaDoc', false)
  def skipMavenDeploy = config.get('skipMavenDeploy', false)
  def dockerRegistry = config.get('dockerRegistry', pipelineProperties.get('usb.docker.registry'))
  def dockerNameSpace = config.get('dockerNameSpace', pipelineProperties.get('usb.docker.namespace'))
  def dockerBuildDir = config.get('dockerBuildDir', pwd())
  def mavenArgs = config.get('mavenArgs', [])
  def proxyEnabled = config.get('proxyEnabled', false)
  def defaultProxy = config.get('defaultProxy', proxyEnv)
  def defaultMavenSettings = config.get('defaultMavenSettings', '-s ./settings.xml')
  def mavenSettingsInJenkins = config.get('mavenSettingsInJenkins', true)

  deleteDir()
  // fresh checkout of the code
  checkout scm

  project.loadProjectProperties()
  // Get release version if passed as part of mavenRelease stage parameter otherwise default it to project.releaseVersion
  def releaseVersion = config.get('releaseVersion', project['version'])
  
  // skipping all kind of test during release
  def mavenReleaseArgs = ["-Dmaven.test.skip=${skipTests} -Dskip.integration.tests=${skipIntegrationTests} -Dmaven.deploy.skip=${skipMavenDeploy} -Dmaven.javadoc.skip=${skipMavenJavaDoc}"]
  mavenArgs.addAll(mavenReleaseArgs)

  mavenBuildArgs = config + [
    mavenGoals: "${mvnGoals.join(' ')}",
    buildWithReleaseVersion: true,
    settingsFileId: config.get('settingsFileId','34950559-48e4-4c53-8e54-aac6381ab762'),
    mavenArgs: mavenArgs,
    environment: "release"
  ]

  mvnBuild.run(mavenBuildArgs)

  dir(dockerBuildDir) {
    stash name: "${project.projectName}-${project.version}", includes: '**/*.jar,**/*.war,**/*.xml,**/*Dockerfile*'
  }

  if (withDockerBuild) {
    // build and push production ready container
    dockerBuild {
      name = project['projectName']
      dockerRegistry = dockerRegistry
      namespace = dockerNameSpace
      version = releaseVersion
      dir = dockerBuildDir
      tagLatest = false
    }
  }
}

return this;