import com.usbank.*

def call(Closure body) {
  def config = [:]
  body.resolveStrategy = Closure.DELEGATE_FIRST
  body.delegate = config
  body()
  run(config)    
}

def run(config) {
  def pipelineProperties = new PipelineProperties()
  def kubectlConfCredentialsId = config.get('kubectlConfCredentialsId', pipelineProperties.get('kubectl.sandbox.conf.credentials.id')) 
  def kubectlArgs = config.get('kubectlArgs', 'get pods')
  def kubectlNamespace = config.get('kubectlNamespace', 'ease')
  def shellOutput = null
  
  timestamps {
    ansiColor('xterm') {
      withCredentials([file(credentialsId: kubectlConfCredentialsId, variable: 'kubernetesconf')]) {
        shellOutput = sh(script: "kubectl --kubeconfig=${kubernetesconf} -n ${kubectlNamespace} ${kubectlArgs}", returnStdout: true)
      }
    }
  }
  return shellOutput
}

return this;
