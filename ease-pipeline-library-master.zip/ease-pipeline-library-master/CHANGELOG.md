# Change Log

This file is maintained in order to track the changes to the modules. Here is an example of the reference we are using to maintain the [changelog.](https://keepachangelog.com/en/0.3.0/)

Note: Please check the following

## [Unreleased]
### Added
- Update Kubernetes Modules
- Minor Bug Fixes
- Added Sonar Scan Module
- Added Maven Release Module
- Added logic to Push code to artifactory
- Updated wiki for the sonar, docker, mvn relase modules
- Integrated governace test within the module

## 19th July 2018
### Added
- Added governance test modules
- Added Kubernetes modules
- Added B/G in for Kubernetes
- Minor Bug Fixes

### Removed
- Code Cleanup.

## 19th June 2018: [1.0.0](https://git-automation.us.bank-dns.com/ease/apiframework/ease-pipeline-library/tree/1.0.0)
### Added
- Added apigee onprem fix.

### Removed
- Code Cleanup.

## 1st June 2018
### Added
- Inital Commit.
- Added maven Build Module.
- Added maven Apigee Build Module.
- Added artifactory push Utility.
- Added apigee token generation Utility.
- Added fortifyScan Module
- Added example Module

### Changed
- Module Designs.

### Removed
- Code Cleanup.
