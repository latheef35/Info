# How can I contribute?

👍🎉 Thank you for your time and effort to contribute!!! 👍🎉

## Guidelines for Contributing

- Issues, new feature and enhancement suggestions for this project are being tracked using GITLAB issues.  
- Ensure issues/bugs/enhancements/new feature are not yet reported by searching our repository's [issues](https://git-automation.us.bank-dns.com/ease/apiframework/ease-pipeline-library/issues) 
- Our team reviews issues, new feature and enhancements on a bi-weekly cadence. 

### Reporting Bugs

This section details on how to submit bugs/issues for this repository. Following these guidelines helps owners, maintainers and the community to understand your issues/bugs and find related issues. Verify in our repository issue list that no similar issue has already been reported.
Create an issue and provide the following:  

- Use a clear and descriptive title for the issue to identify the problem
- Create a detailed description of the issue
- Include the failed Jenkins job link for the error encountered


### Suggesting New Feature / Enhancements

This section guides you through submitting an enhancement suggestion including completely new features and improvements to existing functionality. Following these guidelines helps owners, maintainers and the community understand your suggestion and find related suggestions.

- Use a clear and descriptive title for the issue to identify the feature/enhancement
- Provide a step-by-step description of the suggested enhancement. You can put as many details as you want
- Explain why this enhancement is needed
- Identify the users of this new feature/enhancement

#### Steps on how to contribute a module in the EASE pipeline library

* Please follow the common coding best practices which are defined [here.](https://git-automation.us.bank-dns.com/ease/apiframework/ease-pipeline-library/wikis/coding-standards)
* Here is the [example module](https://git-automation.us.bank-dns.com/ease/apiframework/ease-pipeline-library/blob/master/vars/example.groovy) you can use as a reference.
* In the above example we are creating a module which will print the input provided in the module

**Example**

```
 # the output on the console will be "Hello World". 
 # So whatever input one provide to the module will be printed on the console
 # Module Example
 # @params message String
 stage("Writing Example Module") {
     node('jenkins_slave') {
      example {
        // message is the param to the module
        message = "Hello World"
      }
    }
  } 
```
**Output**

```

  Hello World.
```

* Here is the link to understand more the different Jenkins pipeline libraries [available modules](https://jenkins.io/doc/).

### Pull Request Process

#### Cleaning up

Prior to submitting your pull request, you might want to do a few things to clean up your branch and make it as simple as possible for the original repo's maintainer to test, accept, and merge your work.

If any commits have been made to the upstream master branch, you should rebase your development branch so that merging it will be a simple fast-forward that won't require any conflict resolution work.

```
  # If there were any new commits, rebase your development branch.
  git checkout newfeature
  git rebase master
```

Now, it may be desirable to squash some of your smaller commits down into a small number of larger more cohesive commits. You can do this with an interactive rebase:

```
  # Rebase all commits on your development branch
  git checkout 
  git rebase -i master
```

This will open up a text editor where you can specify which commits to squash.

#### Pull Request Guidelines

- Fill in the PR [template](pull-request-template)
- Update the documentation related to your changes

#### Submitting

Once you've committed and pushed all of your changes to Gitlab, select your development branch, and click the pull request button. If you need to make any adjustments to your pull request, just push the updates to Gitlab. Your pull request will automatically track the changes on your development branch and update.
