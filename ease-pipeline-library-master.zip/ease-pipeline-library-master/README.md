# api-pipeline-library

This are light weight inner-source jenkins pipline libraries which supports the CICD process. It consists of modules to build the project and deploy the project to different environments.
## Architecture Diagram

![ease](img/ease.png)

## Release Version
* Stable Version [1.0.0](https://git-automation.us.bank-dns.com/ease/apiframework/ease-pipeline-library/tree/1.0.0)
* Details of the previous [changes.](https://git-automation.us.bank-dns.com/ease/apiframework/ease-pipeline-library/blob/master/CHANGELOG.md)

## Project Directory Structure

Note: The project directory structure has been in standards with the jenkins pipeline recommended structure.

Here is the [link](https://jenkins.io/doc/book/pipeline/shared-libraries/#global-shared-libraries)

```
	(root)
	+- src                     # Groovy source files
	|   +- org
	|       +- foo
	|           +- Bar.groovy  # for org.foo.Bar class
	+- vars
	|   +- foo.groovy          # for global 'foo' variable
	|   +- foo.txt             # help for 'foo' variable
	+- resources               # resource files (external libraries only)
	|   +- org
	|       +- foo
	|           +- bar.json    # static helper data for org.foo.Bar
```

## Module Usage
* Here is the [link](https://git-automation.us.bank-dns.com/ease/apiframework/ease-pipeline-library/wikis/module-usage) for the same.

## Contribution
* Contributions are 11,000,000% welcome! That's a lot! 😃
* Please file issues for any bugs you find or features you'd like to see. And if you're up for it, send in a pull request.
* Here is the [link](https://git-automation.us.bank-dns.com/ease/apiframework/ease-pipeline-library/wikis/how-to-contribute) which explains the contribution process.
* Getting started on how to write the [modules](https://git-automation.us.bank-dns.com/ease/apiframework/ease-pipeline-library/wikis/how-to-contribute#steps-on-how-to-contribute-a-module-in-the-ease-pipeline-library).
* While logging an Issues using the gitlab make sure to use the predefined issue template.

## Code of Conduct
* Here is the [link](https://git-automation.us.bank-dns.com/ease/apiframework/ease-pipeline-library/wikis/code-of-conduct)

## TODO's
* Add Modules for the service levels.
* Add test for the modules.
* Write lots of test.

## Contributors
* 👍🎉 Thanks to our awesome contributors!!! 👍🎉
* Please Reach out to the `EASE-APISharedSolutions-Framework@usbank.com` Team for any more details
