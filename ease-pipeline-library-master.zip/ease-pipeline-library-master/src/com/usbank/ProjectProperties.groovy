package com.usbank

/**
* TODO this file will need to be modified based on the case 
* per basis.
*/

def loadProjectProperties() {
  String projectName
  String projectUrl
  String version
  String snapshotVersion
  String commitHash
  String branch

  def projectVersion = null
  def snapVersion = null

  def gitUrl = sh(script: 'git remote -v | grep push', returnStdout: true).trim().split("\\s+")
  def gitProjectUrl = gitUrl[1]
  def gitProjectName = gitProjectUrl.split("/").last().split("\\.").first()
  def gitCommitHash = sh(script: 'git log -1 --format="%H"', returnStdout: true).trim()

  // since env.BRANCH_NAME works only in case of multibranch pipeline plugins
  def branchName = sh(script: 'git name-rev --name-only HEAD', returnStdout: true).trim()
  // check for maven project
  def pomExists = fileExists 'pom.xml'
  // check for node project
  def nodeProjectExists = fileExists 'package.json'

  this.projectUrl = gitProjectUrl
  this.projectName = gitProjectName
  this.version = projectVersion
  this.snapshotVersion = snapVersion
  this.commitHash = gitCommitHash
  this.branch = branchName
  
  if(pomExists) {
    def pomObject = readMavenPom()
    this.version = getNormalizedPomVersion()
    this.projectName = getMavenProjectName()
    this.snapshotVersion = getPomVersion()
  }
  
  if(nodeProjectExists) {
    def packageJson = readJSON file: 'package.json'
    this.version = packageJson.version
    this.projectName = packageJson.name
  }
}

def getNormalizedPomVersion() {
  def version = getPomVersion()
  version = version.split("-")[0].toString()
  // pad jenkins build number.
  version = version.split("\\.")
  version[version.size()-1] = env.BUILD_NUMBER
  return version.join(".")
}

def getPomVersion() {
  def pomObject = readMavenPom()
  def version = pomObject.version
  return version
}

def getMavenProjectName() {
  def pomObject = readMavenPom()
  return pomObject.name
}

return this;
