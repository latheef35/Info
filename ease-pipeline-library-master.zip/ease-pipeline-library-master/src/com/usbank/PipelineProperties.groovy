package com.usbank

/**
* TODO this file will need to be modified based on the case 
* per basis.
*/

public String get(key) {
  def libarayResources = libraryResource 'pipeline.properties'
  def properties = readProperties text: libarayResources.toString()
  return properties[key]
}

public String getApigeeTokenUrl(String env) {
  def key = 'apigee.' + env + '.url'
  return get(key)
}

return this;
