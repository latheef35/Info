package com.usbank

// TO DO work on simplyfying the logic

def createAndVerifyGreenDeployment(Map config=[:]) {
  checkIfDeploymentExist(config)
  config['message'] = "Do you want to continue with creating green deployment"
  inputRequest(config)
  env.DEPLOYMENT_FILE_NAME = config.deploymentFileName
  def yaml = readYamlFile(config.deploymentFileName, config.noramlizedEnv)
  yaml = updateDeploymentYaml(config, yaml)
  config['deploymentFileName'] = "deployment-${config.noramlizedEnv}-${config.deploymentVersion}.yaml"
  writeYaml file: config.deploymentFileName, data: yaml
  echo "INFO: current deployment file for ${config.deploymentVersion}"
  sh "cat ${config.deploymentFileName}"
  config['kubectlArgs'] = "apply -f ${config.deploymentFileName}"
  kubectl.run(config)
  verifyDeployment(config)
  config['deploymentFileName'] = env.DEPLOYMENT_FILE_NAME
}

def deleteBlueDeployment(Map config=[:]) {
  config['message'] = "Do you want to continue with deleting blue deployment"
  inputRequest(config)
  deleteDeployment(config, env.PREVIOUS_DEPLOYMENT_VERSION)
}

def createService(Map config=[:]) {
  if(checkIfServiceExist(config)) {
    config['message'] = "creating service"
    inputRequest(config)
    serviceDeploymentHelper(config)
  }
}

def createIngress(Map config=[:]) {
  config['message'] = "Do you want to continue with creating ingress rule"
  inputRequest(config)
  def yaml = readYamlFile(config.ingressFileName, config.noramlizedEnv)
  def ingressFileName = "ingress-${config.noramlizedEnv}-${config.deploymentVersion}.yaml"
  writeYaml file: ingressFileName, data: yaml
  echo "INFO: current ingress file for ${config.deploymentVersion}"
  sh "cat ${ingressFileName}"
  config['kubectlArgs'] = "apply -f ${ingressFileName}"
  kubectl.run(config)
}

def createPersistentVolume(Map config=[:]) {
  config['message'] = "Do you want to continue with creating persistant volume"
  inputRequest(config)
  def yaml = readYamlFile(config.persistantVolumeFileName, config.noramlizedEnv)
  def persistantVolumeFileName = "persistantvolume-${config.noramlizedEnv}-${config.deploymentVersion}.yaml"
  writeYaml file: persistantVolumeFileName, data: yaml
  echo "INFO: current persistant volume file for ${config.deploymentVersion}"
  sh "cat ${persistantVolumeFileName}"
  config['kubectlArgs'] = "apply -f ${persistantVolumeFileName}"
  kubectl.run(config)
}

def createPersistentVolumeClaim(Map config=[:]) {
  config['message'] = "Do you want to continue with creating persistant volume claim"
  inputRequest(config)
  def yaml = readYamlFile(config.persistantVolumeClaimFileName, config.noramlizedEnv)
  def persistantVolumeClaimFileName = "persistantvolumeclaim-${config.noramlizedEnv}-${config.deploymentVersion}.yaml"
  writeYaml file: persistantVolumeClaimFileName, data: yaml
  echo "INFO: current persistant volume claim file for ${config.deploymentVersion}"
  sh "cat ${persistantVolumeClaimFileName}"
  config['kubectlArgs'] = "apply -f ${persistantVolumeClaimFileName}"
  kubectl.run(config)
}

def rollBackDeployment(Map config=[:]) {
  try {
    config['message'] = "Do you want to continue with rolling back deployment"
    inputRequest(config)
    def yaml = readYamlFile(config.deploymentFileName, config.noramlizedEnv)
    def name = yaml.metadata.name + "-" + config.deploymentVersion
    deleteDeployment(config, name)
    config['deploymentVersion'] = getVersionFromPreviousDeployment(env.PREVIOUS_DEPLOYMENT_VERSION)
    config['serviceFileName'] = env.SERVICE_DEPLOYMENT_FILE
    sh "rm -rf service-${config.noramlizedEnv}-${config.deploymentVersion}.yaml"
    serviceDeploymentHelper(config)
    return false 
  } catch(Exception ex) {
    echo "INFO: Rolled back aborted by user. Running this job"
  }
  return true
}

def getVersionFromPreviousDeployment(previousDeploymentVersion) {
  def previousDpVersion = previousDeploymentVersion.split("-")
  return previousDpVersion[previousDpVersion.size()-1]
}

def deleteDeployment(Map config=[:], deploymentName) {
  echo "INFO: deleteting the deployment ${deploymentName}"
  config['kubectlArgs'] = "delete deployments ${deploymentName}"
  kubectl.run(config)
}

def goLive(Map config=[:]) {
  config['message'] = "Do you want continue with making green deployment live"
  try {
    inputRequest(config)
    config['serviceFileName'] = env.SERVICE_DEPLOYMENT_FILE
    sh "rm -rf service-${config.noramlizedEnv}-${config.deploymentVersion}.yaml"
    serviceDeploymentHelper(config)
  } catch(Exception ex) {
    echo "INFO: Deleting the current deployment. Blue/Green Switch failed."
    def yaml = readYamlFile(env.DEPLOYMENT_FILE_NAME, config.noramlizedEnv)
    def name = yaml.metadata.name + "-" + config.deploymentVersion
    deleteDeployment(config, name)
    throw ex
  }
}

def serviceDeploymentHelper(Map config=[:]) {
  def yaml = readYamlFile(config.serviceFileName, config.noramlizedEnv)
  yaml = updateServiceYaml(yaml, config.deploymentVersion)
  config['serviceFileName'] = "service-${config.noramlizedEnv}-${config.deploymentVersion}.yaml"
  writeYaml file: config.serviceFileName, data: yaml
  echo "INFO: current service file for ${config.deploymentVersion}"
  sh "cat ${config.serviceFileName}"
  config['kubectlArgs'] = "apply -f ${config.serviceFileName}"
  kubectl.run(config)
}

def inputRequest(Map config=[:]) {
  if(config.noramlizedEnv == 'prod') {
    input(id: 'userInput', message: "${config.message}?")
  }
}

def readYamlFile(fileName, env) {
  def yaml = readYaml file: fileName
  return yaml[env]
}

def updateDeploymentYaml(config, yaml) {
  def containersConfiguration = yaml.spec.template.spec.containers
  def name = yaml.metadata.name + "-" + config.deploymentVersion
  yaml.metadata.name = name
  yaml.spec.selector.matchLabels.name = name
  yaml.spec.template.metadata.labels.name = name
  for(int i = 0; i<containersConfiguration.size(); i++) {
    yaml.spec.template.spec.containers[i].image = "${config.dockerRegistry}/${config.namespace}/${config.imageName[0]}:${config.deploymentVersion}"
  }
  return yaml
}

def updateServiceYaml(yaml, version) {
  def name = yaml.metadata.name + "-" + version
  yaml.spec.selector.name = name
  return yaml
}

def verifyDeployment(Map config=[:]) {
  // Wait until the Deployment is ready by checking the MinimumReplicasAvailable condition.
  def deploymentName = readYaml file: config.deploymentFileName
  def count = 0
  retry(30) {
    sleep 5
    config['kubectlArgs'] = "get deploy ${deploymentName.spec.selector.matchLabels.name} -o json"
    def deploymentData = kubectl.run(config)
    def jsonObj = readJSON text: deploymentData.toString()
    def conditions = jsonObj.status.conditions
    for(statusObj in conditions) {
      if(statusObj.reason != 'MinimumReplicasAvailable' && statusObj.status != 'True') {
        try {
          count++
          getPodDeploymentLogs(config, "${deploymentName.spec.selector.matchLabels.name}")
          error "Retrying attempt ${count} to check the status. Container are not stable.... ${statusObj.toString()}"
        } catch (Exception ex) {
          if(count == 30) {
            deleteDeployment(config, deploymentName.spec.selector.matchLabels.name)
          }
          throw ex
        }
      }
    }
    echo "INFO: containers are stable, getting the logs"
    getPodDeploymentLogs(config, "${deploymentName.spec.selector.matchLabels.name}")
  }
}

def checkIfDeploymentExist(Map config=[:]) {
  def deploymentName = readYamlFile(config.deploymentFileName, config.noramlizedEnv)
  def name = deploymentName.metadata.name + "-" + config.deploymentVersion
  config['kubectlArgs'] = "get deployments ${name}"
  def errorFlag = false
  try {
    def status = kubectl.run(config)
    if(status.contains(name)) {
      errorFlag = true
    }
  } catch(Exception e) {
    echo "INFO: creating deployment with name ${name}"
  } finally {
    if(errorFlag) {
      error "deployment with ${name} already exist"
    }
  }
}

def checkIfBlueExist(Map config=[:]) {
  if (env.PREVIOUS_DEPLOYMENT_VERSION == null) {
    return false
  }

  def name = env.PREVIOUS_DEPLOYMENT_VERSION
  config['kubectlArgs'] = "get deployments ${name}"
  try {
    kubectl.run(config)
    return true
  } catch(Exception e) {
    echo "INFO: Error deployment ${name} doesn't exist"
    return false
  }
}

def checkBlueDeployment(Map config=[:], deploymentName) {
  echo "INFO: Check if Blue deployment exists"
  config['kubectlArgs'] = "get deployments ${deploymentName}"
  kubectl.run(config)
}

def getPodDeploymentLogs(Map config=[:], deploymentName) {
  try {
    config['kubectlArgs'] = "get pods | grep ${deploymentName} | awk -F ' ' '{print \$1}'"
    def podsName = kubectl.run(config).split('\n')
    echo podsName.toString()
    if(podsName[0].toString().trim() != '' || podsName[0].toString().trim() != null) {
      echo "INFO: getting pod deployment logs for pod: ${podsName[0].toString().trim()}"
      config['kubectlArgs'] = "describe pods ${podsName[0].toString().trim()}"
      def podLogs = kubectl.run(config)
      echo "INFO: ${podLogs.trim()}"
    } else {
      echo "ERROR: pods not found for the current deployment"
    }
  } catch(Exception e) {
    echo "ERROR: unable to get the pod deployment logs"
  }
}

def checkIfServiceExist(Map config=[:]) {
  env.SERVICE_DEPLOYMENT_FILE = config.serviceFileName
  def serviceName = readYamlFile(config.serviceFileName, config.noramlizedEnv)
  config['kubectlArgs'] = "get svc ${serviceName.metadata.name} -o json"
  try {
    def service = kubectl.run(config)
    def jsonObj = readJSON text: service.toString()
    env.PREVIOUS_DEPLOYMENT_VERSION = jsonObj.spec.selector.name
    echo "INFO: service already exist with name ${serviceName.metadata.name}"
  } catch(Exception e) {
    echo "INFO: creating service with name ${serviceName.metadata.name}"
    return true
  }
  return false
}

return this;
